package http://hl7.org/fhir/us/breastcancer/ImplementationGuide/1;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class DiagnosticService {

}
